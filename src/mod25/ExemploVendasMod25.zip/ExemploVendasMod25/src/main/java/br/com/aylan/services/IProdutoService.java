/**
 * 
 */
package br.com.aylan.services;

import br.com.aylan.domain.Produto;
import br.com.aylan.services.generic.IGenericService;

/**
 * @author aylan
 *
 */
public interface IProdutoService extends IGenericService<Produto, String> {

}
