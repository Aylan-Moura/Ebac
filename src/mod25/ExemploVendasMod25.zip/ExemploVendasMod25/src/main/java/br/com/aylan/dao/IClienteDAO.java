/**
 * 
 */
package br.com.aylan.dao;

import br.com.aylan.dao.generic.IGenericDAO;
import br.com.aylan.domain.Cliente;

/**
 * @author aylan
 *
 */
public interface IClienteDAO extends IGenericDAO<Cliente, Long> {


}
