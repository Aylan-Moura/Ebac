/**
 * 
 */
package br.com.aylan.dao;

import br.com.aylan.dao.generic.IGenericDAO;
import br.com.aylan.domain.Produto;

/**
 * @author aylan
 *
 */
public interface IProdutoDAO extends IGenericDAO<Produto, String>{

}
